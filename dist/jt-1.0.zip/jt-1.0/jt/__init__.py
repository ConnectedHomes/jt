from .jt import *

def main():
    return run()
